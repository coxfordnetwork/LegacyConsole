#version 150

const vec3 black = vec3(0.278, 0.09, 0.063);

const vec3 dark_blue = vec3(0, 0, 0.667);

const vec3 dark_green = vec3(0, 0.667, 0);

const vec3 dark_aqua = vec3(0, 0.667, 0.667);

const vec3 dark_red = vec3(0.667, 0, 0);

const vec3 dark_purple = vec3(1, 0, 0.667);

const vec3 gold = vec3(1, 0.667, 0);

const vec3 gray = vec3(0.921, 0.741, 0.356);

const vec3 dark_gray = vec3(0.333, 0.333, 0.333);

const vec3 blue = vec3(0.333, 0.333, 1);

const vec3 green = vec3(0.333, 1, 0.333);

const vec3 aqua = vec3(0.333, 1, 1);

const vec3 red = vec3(1, 0.333, 0.333);

const vec3 light_purple = vec3(1, 0.333, 1);

const vec3 yellow = vec3(1, 1, 0.333);

const vec3 white = vec3(0.949, 0.788, 0.357);

const vec3 title_text_color = vec3(0.776, 0.62, 0.282);

const vec3 body_text_color = vec3(1, 1, 1);

const vec3 experience_text_color = vec3(0.5, 1, 0);
